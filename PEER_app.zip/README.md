# PEER_app
Shiny app for crowdsourcing ground truth data collection, supporting mapping of Amazon wetland habitats
